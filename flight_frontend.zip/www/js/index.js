
//function to turn access_token to string
function parseJwt (token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
  
}

var access_token = new URLSearchParams(window.location.hash).get('id_token');

parseJwt(access_token)
// console.log(access_token);
console.log(parseJwt(access_token).email)
//access_token is added to local storage
localStorage.setItem("email", parseJwt(access_token).email);

var ema = localStorage.getItem('email')

    
document.getElementById('em').innerHTML=ema

