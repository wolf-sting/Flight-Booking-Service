


        const source = document.getElementById('Source')
        const destination = document.getElementById('destination')
        const but = document.getElementById('btn1')
        const but2 = document.getElementById('btn2')
        
        function f2() {

            // fetch('https://fakestoreapi.com/products')
            // .then((data)=>{
            //     return data.json();
            // }).then((objectdata)=>{
            //     // console.log(objectdata)
            //     let tabledata = "";
            //     objectdata.forEach(element => {
            //         // console.log(element)
                        
            //         tabledata+= ` <tr>
            //         <th scope="row">${element.title}</th>
            //         <td>${element.title}</td>
            //         <td>${element.description}</td>
            //         <td>${element.category}</td>
            //         <td><button type="button" class="btn btn-primary">Primary</button></td>
                    
            //       </tr>`
                  
            //     });
            //     document.getElementById("tbod").innerHTML=tabledata;   
            // })

//fetching flight list using api(custom search)
        fetch('https://kwkzd4xg78.execute-api.us-west-2.amazonaws.com/dev/api/Flight/')
        .then((flight)=>
        {
            return flight.json()
        }).then((fdata)=>{
            // console.log(fdata);

            let tabledata = "";
          var as = [];
          var i = 0;
          
        
            fdata.slice(0,10).forEach(element => {
                // console.log(element)
                    
                tabledata+= ` <tr >
                <th id="ff" scope="row">${element.source}</th>
                <td>${element.destination}</td>
                <td>${element.airline}</td>
                <td>${element.departure}</td>
                <td>${element.arrival}</td>
            
                <td>${element.fare} USD</td>
                <td>  <button type="button" id="${i}" value="${i}"    href="login.html"  class="btn btn-primary">Book Now!</button>  
              
                
                </td>
               
              </tr>`
            as.push(element)
            i++

            //   <td><button type="button" id="t"  onclick="show()"  href="login.html"  class="btn btn-primary">Book Now!</button>  
                
            // console.log(${element.callsign})   <td><button type="button" id="t" onclick="window.location='login.html'" href="login.html"  class="btn btn-primary">Book Now!</button></td>
              
            });
        
            document.getElementById("tbod").innerHTML=tabledata;

            // document.getElementById(`${i}`).onclick = function() {
            //     //do something
            //     console.log(as[bu])
            // }

// asffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
            // const but5 = document.getElementById('1')
            
            // function t(){
            //     console.log(as[but5.value])
            // }
            
            //     but5.addEventListener('click',t)

        //   qfassssdddddddfssssssssssssssssssasfffffffffffffffffffffffffffffffffffffffffffff
            

        
            for(j=0;j<4;j++){
                 
            function t(){
                //  console.log(as[but5.value].callsign,as[but5.value].estArrivalAirport,as[but5.value].estDepartureAirport)
                 const f= localStorage.setItem('flight',as[but5.value].id)
                  console.log(localStorage.getItem('flight'))
                    
                     document.getElementById('y').innerHTML=localStorage.getItem('flight')
                 window.location.href="result.html"

            }
            

            const but5 = document.getElementById(j)
            // console.log(but5)
        
            but5.addEventListener('click',t)
        
          
          

             
//    window.onload=function(){
//     // var btn = document.getElementById("go-button");
//     // btn.addEventListener("click", buttonClicked, true);
//     const but5 = document.getElementById(ts)
//     but5.addEventListener('click',t,true)
            
//   }
//     ts++

            }
        })
        }

            
        but2.addEventListener('click',f2)

        
        

        

//fetching flight list using api(All Flights)
        function f1(){

            console.log(`${source.value}`)
            
        fetch(`https://kwkzd4xg78.execute-api.us-west-2.amazonaws.com/dev/api/Flight/search/${source.value}/${destination.value}/`)
        .then((data)=>{
            return data.json();
        }).then((objectdata)=>{
            // console.log(objectdata)
            let tabledata = "";
            // objectdata.forEach(element => {
                console.log(objectdata)

                var as = [];
          var i = 0;
                    
                objectdata.slice(0,10).forEach(element =>{

                    tabledata+= ` <tr>
                    <th scope="row">${element.source}</th>
                    <td>${element.destination}</td>
                    <td>${element.airline}</td>
                    <td>${element.departure}</td>
                    <td>${element.arrival}</td>
                    <td>${element.fare} &dollar</td>
                    <td>  <button type="button" id="${i}" value="${i}"    href="login.html"  class="btn btn-primary">Book Now!</button>  
              
                    
                </tr>`
                as.push(element)
                i++
                })

               
            
            // });
            document.getElementById("tbod").innerHTML=tabledata; 
            
            for(j=0;j<4;j++){
                 
                function t(){
                    //  console.log(as[but5.value].callsign,as[but5.value].estArrivalAirport,as[but5.value].estDepartureAirport)
                     const f= localStorage.setItem('flight',as[but5.value].source)
                      console.log(localStorage.getItem('flight'))
                        
                         document.getElementById('y').innerHTML=localStorage.getItem('flight')
                     window.location.href="result.html"
    
                }
                
    
                const but5 = document.getElementById(j)
                // console.log(but5)
            
                but5.addEventListener('click',t)
            }
        })
            

        }



        but.addEventListener('click',f1)
        