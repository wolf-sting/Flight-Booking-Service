// const e = require("express");


var res = localStorage.getItem('flight')

var ema = localStorage.getItem('email')


// console.log(ema);

    const j = document.getElementById('a')
   const t = document.getElementById('title')
   const dis = document.getElementById('ds')
   
   const form = document.getElementById('formm')
   
   selectElement = document.querySelector('#title');

    var fname = document.getElementById('namep')

    var lname = document.getElementById('namel')
    
    var pno = document.getElementById('pno')
    
    var dob = document.getElementById('dob')
    
    var phone = document.getElementById('phoneno')




    
    const fb = document.getElementById('fb')







//fetching selected flight
    fetch(`https://kwkzd4xg78.execute-api.us-west-2.amazonaws.com/dev/api/Flight/${res}/`)
    .then((data)=>{
      return  data.json()
    }).then((res)=>{
            console.log(res.source)

            document.getElementById('src').innerHTML = res.source
            document.getElementById('dst').innerHTML = res.destination
            document.getElementById('gbp').innerHTML = res.fare
            document.getElementById('air').innerHTML = res.airline
            document.getElementById('dum').innerHTML = res.id
        //   var a=  JSON.stringify(res)
            console.log(res.id);

            loc = res.id
        // document.getElementById('tx').innerHTML = a





//form on submit function
        form.addEventListener('submit',function(e) {

        
            var fname = document.querySelector('#namep').value
        
            var lnamee = document.querySelector('#namel').value
            
            var pno = document.querySelector('#pno').value
            
            var dobb = document.querySelector('#dob').value
            
            var phone = document.querySelector('#phoneno').value
        
                console.log(fname);
                
                console.log(lnamee);
                
                console.log(pno);
                
                console.log(dobb)
                
                console.log(phone);
                console.log(res.id);
        
        
                age = document.querySelector('#dob').value
               
        
                    // function discount(){
        
                    //     agesli = age.slice(0,4)
        
                    //     if(2023 -agesli <18)
                    //     {
                    //         alert('congratulations you recieved student discount')
                    //         cal = (25/100)*document.getElementById('gbp').innerHTML
                    //         document.getElementById('gbp').innerHTML = cal
            
                    //     }
                    //     else
                    //     {
                    //         alert('No discounts available')
                    //     }
                    // }
        
        
                e.preventDefault();
        
                const pname = document.querySelector('#namep').value
                const lname = document.querySelector('#namel').value
                const dob = document.querySelector('#dob').value
        
        
        
               
                console.log(selectElement.value, pname,lname,dob);
                console.log( document.getElementById('gbp'));
               
        
                console.log(res.id);
        
                alert('please procede to payment')

                //payment buttons and function(paypal api)
        paypal.Buttons({
            // Sets up the transaction when a payment button is clicked

            
            createOrder: (data, actions) => {
                
              return actions.order.create({
                purchase_units: [{
                  amount: {
                    // curr ency_code: "GBP",
                    value: document.getElementById('gbp').innerHTML // Can also reference a variable or function
                  }
                }]
              });
            },
            // Finalize the transaction after payer approval
            onApprove: (data, actions) => {
              return actions.order.capture().then(function(orderData) {
                // Successful capture! For dev/demo purposes:
                console.log('Capture result', orderData, JSON.stringify(orderData, null, 2));
                const transaction = orderData.purchase_units[0].payments.captures[0];
                alert(`Transaction ${transaction.status}: ${transaction.id}\n\nSee console for all available details`);
                // When ready to go live, remove the alert and show a success message within this page. For example:
                // const element = document.getElementById('paypal-button-container');
                // element.innerHTML = '<h3>Thank you for your payment!</h3>';
                // Or go to another URL:  actions.redirect('thank_you.html');
               
                //post form details to booking api
                fetch('https://kwkzd4xg78.execute-api.us-west-2.amazonaws.com/dev/api/Booking/',{
                    method:'post',
                    body:JSON.stringify(
                        {
                            
                            first_name:fname,
                            last_name:lnamee,
                            passport_no:pno,
                            date_of_birth:dobb,
                            phone:phone,
                            flight:res.id,
                            email:ema
        
                        }
                        
        
                    ),headers:{
                        "Content-Type":"application/json; charset=UTF-8"
                    }
                }).then(function(response){
                    return response.json()
                    
                }).then(function(text){
                    // var result = response;
                        console.log(text);
                        // console.log(text.body);
                    console.log(text['id']);
                    localStorage.setItem("bid",text['id'])
                   
                  

                }).catch(function(error){
                    console.log(error);
                })

                
                var bid = localStorage.getItem("bid")
                var kir = JSON.stringify({purchase_id:transaction.id,destination:ema,booking:bid})
                console.log(kir);

                //if payment success post booking and trxn id to email api
                    fetch('https://kwkzd4xg78.execute-api.us-west-2.amazonaws.com/dev/api/EmailRecord/',{
                        method:'post',
                        body:JSON.stringify(
                            {
                                
                                purchase_id:transaction.id,
                                destination:ema,
                                // kind:'PCS',
                                booking:bid

            
                            }
                                
                            
                        ),headers:{
                            "Content-Type":"application/json; charset=UTF-8"
                        } 
                    }).then(function(response){
                        return response.json()
                        
                    }).then(function(text){
                        // var result = response;
                             console.log(text);
                            // console.log(text.body);
                        // console.log(text['id']);
                      
    
                    }).catch(function(error){
                        console.log(error);
                    })
    
                    window.location.href="buuking_success.html"



                
              });


                







            }



          }).render('#paypal-button-container');






        
        
        
                // const formdataa = new FormData(this);
              
            })
        
        







    })




    function f() {
        localStorage.removeItem('flight');
        window.location.reload();
        window.location.href="flight_list.html"
    }

    j.addEventListener('click',f)





    // function namea() {

    //     output = selectElement.value;
       
    //     console.log(output)
    // }
    // fb.addEventListener('click',namea)











    ////////////////////////////////////////////////


    
        function ddd() {

            age =document.querySelector('#dob').value
       

            agesli = age.slice(0,4)

            if(2023 -agesli <18)
            {
                alert('congratulations you recieved student discount')
                cal = (25/100)*document.getElementById('gbp').innerHTML
                fin = document.getElementById('gbp').innerHTML-cal
                document.getElementById('gbp').innerHTML = fin



    
            }
            else
            {
                alert('No discounts available')
            }

        }
    
        dis.addEventListener('click',ddd)







