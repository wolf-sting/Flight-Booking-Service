"""ticket URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
# from django.contrib import admin
from django.urls import path, re_path
# from flight.views import AirlineList, AirlineDetail, AirplaneDetail, AirplaneList, AirportDetail, AirportList, RouteDetail, RouteList
from flight.views import FlightDetail, FlightList, RetrieveFlightBySourceDestination, BookingDetail, BookingList, EmailRecordDetail, EmailRecordList
# from flight.views import UserProfileAPIView
# from rest_framework.documentation import include_docs_urls


from rest_framework.schemas import get_schema_view



urlpatterns = [
    # path('admin/', admin.site.urls),
    # path('api/user', UserProfileAPIView.as_view(), name='my_profile'),
    # path('api/Airline/', AirlineList.as_view()),
    # path('api/Airline/<int:airline_id>/', AirlineDetail.as_view()),
    # path('api/Airplane/', AirplaneList.as_view()),
    # path('api/Airplane/<int:airplane_id>/', AirplaneDetail.as_view()),
    # path('api/Airport/', AirportList.as_view()),
    # path('api/Airport/<int:airport_id>/', AirportDetail.as_view()),
    # path('api/Route/', RouteList.as_view()),
    # path('api/Route/<int:route_id>/', RouteDetail.as_view()),
    # path('api/Seat/', SeatList.as_view()),
    # path('api/Seat/<int:seat_id>/', SeatDetail.as_view()),
    path('api/Flight/', FlightList.as_view()),
    path('api/Flight/<int:flight_id>/', FlightDetail.as_view()),
    path('api/Flight/search/<str:source>/<str:destination>/', RetrieveFlightBySourceDestination.as_view()),
    path('api/Booking/', BookingList.as_view()),
    path('api/Booking/<int:booking_id>/', BookingDetail.as_view()),
    path('api/EmailRecord/', EmailRecordList.as_view()),
    path('api/EmailRecord/<int:emailrecord_id>/', EmailRecordDetail.as_view()),    

    path('docs/', get_schema_view(
        title="Easyflight",
        description="API for all things …"
    ), name='openapi-schema'),
]
