from rest_framework import serializers
from .models import Flight,Booking,EmailRecord



# class UserSerializer(serializers.ModelSerializer):
#     """ Used to retrieve user info """

#     class Meta:
#         model = User
#         fields = '__all__'

# class AirlineSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Airline
#         fields = '__all__'


# class AirplaneSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Airplane
#         fields = '__all__'

# class AirportSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Airport
#         fields = '__all__'

# class RouteSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Route
#         fields = '__all__'

# class SeatSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Seat
#         fields = '__all__'

class FlightSerializer(serializers.ModelSerializer):
    class Meta:
        model = Flight
        fields = '__all__'

class BookingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Booking
        fields = '__all__'

class EmailRecordSerializer(serializers.ModelSerializer):

    def create(self, validated_data):
        from django.core.mail import send_mail
        # if validated_data["kind"] == "PCS":
        send_mail(
        "EasyFlight Purchase Status",
        "Booking successfull. Your Purchaseid is " + validated_data["purchase_id"],
        'kevinspacyiust@gmail.com',
        [validated_data["destination"]]
        )
        print("I sent the Email")
        # else:
        #     send_mail(
        #     "EasyFlight Purchase Status",
        #     "Booking failed. Your Purchaseid is " + validated_data["purchase_id"],
        #     'kevinspacyiust@gmail.com',
        #     [validated_data["destination"]]
        #     )
        # send_mail(
        # "EasyFlight Purchase Status",
        # "Booking successfull. Your Purchaseid is ",
        # 'kevinspacyiust@gmail.com',
        # ["shrsanaee@gmail.com"]
        # )
        return EmailRecord.objects.create(**validated_data)
    class Meta:
        model = EmailRecord
        fields = '__all__'