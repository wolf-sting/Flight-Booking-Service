# from django.shortcuts import render

# Create your views here.
from rest_framework import generics
from .serializers import FlightSerializer,BookingSerializer, EmailRecordSerializer
# from .serializers import UserSerializer
from .models import Flight,Booking,EmailRecord


# from rest_framework.mixins import RetrieveModelMixin
# from rest_framework.permissions import IsAuthenticated




# class UserProfileAPIView(RetrieveModelMixin, generics.GenericAPIView):
#     serializer_class = UserSerializer
#     permission_classes = (IsAuthenticated, )

#     def get_object(self):
#         return self.request.user

#     def get(self, request, *args, **kwargs):
#         """
#         User profile
#         Get profile of current logged in user.
#         """
#         return self.retrieve(request, *args, **kwargs)


# class AirlineList(generics.ListCreateAPIView):
#     queryset = Airline.objects.all()
#     serializer_class = AirlineSerializer

# class AirlineDetail(generics.RetrieveUpdateDestroyAPIView):
#     lookup_url_kwarg = 'airline_id'
#     queryset = Airline.objects.all()
#     serializer_class = AirlineSerializer

# class AirplaneList(generics.ListCreateAPIView):
#     queryset = Airplane.objects.all()
#     serializer_class = AirplaneSerializer

# class AirplaneDetail(generics.RetrieveUpdateDestroyAPIView):
#     lookup_url_kwarg = 'airplane_id'
#     queryset = Airplane.objects.all()
#     serializer_class = AirplaneSerializer

# class AirportList(generics.ListCreateAPIView):
#     queryset = Airport.objects.all()
#     serializer_class = AirportSerializer

# class AirportDetail(generics.RetrieveUpdateDestroyAPIView):
#     lookup_url_kwarg = 'airport_id'
#     queryset = Airport.objects.all()
#     serializer_class = AirportSerializer

# class RouteList(generics.ListCreateAPIView):
#     queryset = Route.objects.all()
#     serializer_class = RouteSerializer

# class RouteDetail(generics.RetrieveUpdateDestroyAPIView):
#     lookup_url_kwarg = 'route_id'
#     queryset = Route.objects.all()
#     serializer_class = RouteSerializer

# class SeatList(generics.ListCreateAPIView):
#     queryset = Seat.objects.all()
#     serializer_class = SeatSerializer

# class SeatDetail(generics.RetrieveUpdateDestroyAPIView):
#     lookup_url_kwarg = 'seat_id'
#     queryset = Seat.objects.all()
#     serializer_class = SeatSerializer

class FlightList(generics.ListCreateAPIView):
    queryset = Flight.objects.all()
    serializer_class = FlightSerializer

class FlightDetail(generics.RetrieveUpdateDestroyAPIView):
    lookup_url_kwarg = 'flight_id'
    queryset = Flight.objects.all()
    serializer_class = FlightSerializer
        
class RetrieveFlightBySourceDestination(generics.ListAPIView):
    serializer_class = FlightSerializer

    def get_queryset(self):
        source = self.kwargs['source']
        destination = self.kwargs['destination']
        my_query_set = None
        if source != '*' and destination != '*':
            my_query_set = Flight.objects.filter(source=source, destination=destination)
        elif source != '*' and destination == '*':
            my_query_set = Flight.objects.filter(source=source)
        elif source == '*' and destination != '*':
            my_query_set = Flight.objects.filter(destination=destination)
        else:
            my_query_set = Flight.objects.all()
        return my_query_set

class BookingList(generics.ListCreateAPIView):
    queryset = Booking.objects.all()
    serializer_class = BookingSerializer

class BookingDetail(generics.RetrieveUpdateDestroyAPIView):
    lookup_url_kwarg = 'booking_id'
    queryset = Booking.objects.all()
    serializer_class = BookingSerializer


class EmailRecordList(generics.ListCreateAPIView):
    queryset = EmailRecord.objects.all()
    serializer_class = EmailRecordSerializer

class EmailRecordDetail(generics.RetrieveUpdateDestroyAPIView):
    lookup_url_kwarg = 'emailrecord_id'
    queryset = EmailRecord.objects.all()
    serializer_class = EmailRecordSerializer

